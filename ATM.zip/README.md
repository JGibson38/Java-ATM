###ATM.Jar###

###A simple ATM Menu written in Java###

###Instructions for use:
1. Download the .zip file.
2. Extract the file to your chosen location.
3. Open a Windows command prompt and cd to the .jar files extraction directory.
4. Invoke the .jar file with the command java -jar ATM.jar

###Future Improvements:
	1. Use of a GUI for improved viewing.
	2. Completion of each menu item
		A. Deposit
		B. Withdrawal
		C. Check Balance
	3. Include sample data for test cases.
	
	